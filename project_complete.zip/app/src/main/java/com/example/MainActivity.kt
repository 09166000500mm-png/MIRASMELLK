package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.AppScreen
import com.example.ui.MainViewModel
import com.example.ui.screens.CampaignScreen
import com.example.ui.screens.ExtractorScreen
import com.example.ui.screens.LeadsScreen
import com.example.ui.screens.RadarScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.RealEstateNavy
import com.example.ui.theme.RealEstatePrimary

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                // Persian RTL support
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    val currentScreen by viewModel.currentScreen.collectAsState()

                    Scaffold(
                        modifier = Modifier.fillMaxSize(),
                        topBar = {
                            TopAppBar(
                                title = {
                                    Column {
                                        Text(
                                            text = "املاک مارکتینگ",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 18.sp
                                        )
                                        Text(
                                            text = when (currentScreen) {
                                                AppScreen.RADAR -> "کاوشگر منطقه و استخراج آگهی‌ها"
                                                AppScreen.LEADS -> "مدیریت سازندگان، خریداران و فروشندگان"
                                                AppScreen.EXTRACTOR -> "استخراج خودکار شماره‌های موبایل"
                                                AppScreen.CAMPAIGN -> "کمپین و ارسال پیامک تبلیغاتی"
                                            },
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                },
                                actions = {
                                    IconButton(
                                        onClick = { viewModel.refreshRadar() },
                                        modifier = Modifier.testTag("appbar_refresh_btn")
                                    ) {
                                        Icon(
                                            Icons.Default.Refresh,
                                            contentDescription = "تازه‌سازی",
                                            tint = RealEstatePrimary
                                        )
                                    }
                                },
                                colors = TopAppBarDefaults.topAppBarColors(
                                    containerColor = MaterialTheme.colorScheme.surface
                                )
                            )
                        },
                        bottomBar = {
                            NavigationBar(
                                modifier = Modifier
                                    .windowInsetsPadding(WindowInsets.navigationBars)
                                    .testTag("bottom_nav_bar"),
                                containerColor = MaterialTheme.colorScheme.surface
                            ) {
                                NavigationBarItem(
                                    selected = currentScreen == AppScreen.RADAR,
                                    onClick = { viewModel.navigateTo(AppScreen.RADAR) },
                                    icon = {
                                        Icon(
                                            if (currentScreen == AppScreen.RADAR) Icons.Filled.TravelExplore else Icons.Outlined.TravelExplore,
                                            contentDescription = "کاوشگر منطقه"
                                        )
                                    },
                                    label = { Text("کاوشگر", fontSize = 11.sp) },
                                    modifier = Modifier.testTag("nav_radar")
                                )

                                NavigationBarItem(
                                    selected = currentScreen == AppScreen.LEADS,
                                    onClick = { viewModel.navigateTo(AppScreen.LEADS) },
                                    icon = {
                                        Icon(
                                            if (currentScreen == AppScreen.LEADS) Icons.Filled.Contacts else Icons.Outlined.Contacts,
                                            contentDescription = "بانک مخاطبان"
                                        )
                                    },
                                    label = { Text("مخاطبان", fontSize = 11.sp) },
                                    modifier = Modifier.testTag("nav_leads")
                                )

                                NavigationBarItem(
                                    selected = currentScreen == AppScreen.EXTRACTOR,
                                    onClick = { viewModel.navigateTo(AppScreen.EXTRACTOR) },
                                    icon = {
                                        Icon(
                                            if (currentScreen == AppScreen.EXTRACTOR) Icons.Filled.Bolt else Icons.Outlined.Bolt,
                                            contentDescription = "استخراج متن"
                                        )
                                    },
                                    label = { Text("استخراج سریع", fontSize = 11.sp) },
                                    modifier = Modifier.testTag("nav_extractor")
                                )

                                NavigationBarItem(
                                    selected = currentScreen == AppScreen.CAMPAIGN,
                                    onClick = { viewModel.navigateTo(AppScreen.CAMPAIGN) },
                                    icon = {
                                        Icon(
                                            if (currentScreen == AppScreen.CAMPAIGN) Icons.Filled.Campaign else Icons.Outlined.Campaign,
                                            contentDescription = "کمپین پیامکی"
                                        )
                                    },
                                    label = { Text("پیامک تبلیغاتی", fontSize = 11.sp) },
                                    modifier = Modifier.testTag("nav_campaign")
                                )
                            }
                        }
                    ) { innerPadding ->
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding)
                        ) {
                            Crossfade(
                                targetState = currentScreen,
                                label = "screen_transition"
                            ) { screen ->
                                when (screen) {
                                    AppScreen.RADAR -> RadarScreen(viewModel = viewModel)
                                    AppScreen.LEADS -> LeadsScreen(viewModel = viewModel)
                                    AppScreen.EXTRACTOR -> ExtractorScreen(viewModel = viewModel)
                                    AppScreen.CAMPAIGN -> CampaignScreen(viewModel = viewModel)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
