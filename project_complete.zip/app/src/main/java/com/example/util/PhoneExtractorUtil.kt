package com.example.util

import com.example.model.LeadCategory

data class ExtractedContact(
    val rawNumber: String,
    val canonicalPhone: String,
    val detectedName: String,
    val suggestedCategory: LeadCategory,
    val contextSnippet: String
)

object PhoneExtractorUtil {

    private val PERSIAN_ARABIC_DIGITS = mapOf(
        '۰' to '0', '۱' to '1', '۲' to '2', '۳' to '3', '۴' to '4',
        '۵' to '5', '۶' to '6', '۷' to '7', '۸' to '8', '۹' to '9',
        '٠' to '0', '١' to '1', '٢' to '2', '٣' to '3', '٤' to '4',
        '٥' to '5', '٦' to '6', '٧' to '7', '٨' to '8', '٩' to '9'
    )

    fun normalizeDigits(input: String): String {
        val sb = StringBuilder(input.length)
        for (ch in input) {
            val mapped = PERSIAN_ARABIC_DIGITS[ch]
            sb.append(mapped ?: ch)
        }
        return sb.toString()
    }

    /**
     * Extracts Iranian mobile phone numbers from any arbitrary text block.
     * Handles Persian/Arabic numerals, spaces, hyphens, prefixes like +98, 0098, 0, or raw 9...
     */
    fun extractContacts(rawText: String, defaultCategory: LeadCategory = LeadCategory.BUILDER): List<ExtractedContact> {
        if (rawText.isBlank()) return emptyList()

        val normalized = normalizeDigits(rawText)
        val lines = normalized.lines()
        val results = mutableListOf<ExtractedContact>()
        val seenNumbers = mutableSetOf<String>()

        // Regex for Iranian mobile numbers: matches 09\d{9}, +989\d{9}, 00989\d{9}, or standalone 9\d{9}
        val phoneRegex = Regex("""(?:(?:\+|00)?98\s*|0)?(9[0-9]{2}[\s\-]?[0-9]{3}[\s\-]?[0-9]{4})""")

        for (line in lines) {
            val matches = phoneRegex.findAll(line)
            for (match in matches) {
                val cleanedDigits = match.value.replace(Regex("""[\s\-\+\(\)]"""), "")
                val standardPhone = when {
                    cleanedDigits.startsWith("0098") -> "0" + cleanedDigits.substring(4)
                    cleanedDigits.startsWith("98") -> "0" + cleanedDigits.substring(2)
                    cleanedDigits.startsWith("09") -> cleanedDigits
                    cleanedDigits.startsWith("9") && cleanedDigits.length == 10 -> "0$cleanedDigits"
                    else -> null
                }

                if (standardPhone != null && standardPhone.length == 11 && standardPhone.startsWith("09")) {
                    if (seenNumbers.add(standardPhone)) {
                        // Extract possible name or title from the surrounding line text
                        val lineWithoutPhone = line.replace(match.value, "").trim()
                        val detectedName = extractPossibleName(lineWithoutPhone)
                        val suggestedCategory = guessCategory(line, defaultCategory)

                        results.add(
                            ExtractedContact(
                                rawNumber = match.value.trim(),
                                canonicalPhone = standardPhone,
                                detectedName = detectedName.ifBlank { "مخاطب ${standardPhone.takeLast(4)}" },
                                suggestedCategory = suggestedCategory,
                                contextSnippet = line.trim().take(80)
                            )
                        )
                    }
                }
            }
        }

        return results
    }

    private fun extractPossibleName(text: String): String {
        val cleaned = text
            .replace(Regex("""[:\-\|\,\;]"""), " ")
            .replace(Regex("""(تلفن|موبایل|شماره|تماس|همراه|واتساپ|تلگرام|پروژه|آدرس|فروش|خرید|سازنده|مالک|مهندس|آقای|خانم)"""), "")
            .trim()

        val words = cleaned.split(Regex("""\s+""")).filter { it.isNotBlank() && it.length > 1 }
        return if (words.isNotEmpty()) {
            words.take(3).joinToString(" ")
        } else {
            ""
        }
    }

    private fun guessCategory(line: String, fallback: LeadCategory): LeadCategory {
        val lower = line.lowercase()
        return when {
            lower.contains("سازند") || lower.contains("پروژه") || lower.contains("مشارکت") ||
                    lower.contains("کلنگی") || lower.contains("انبوه‌ساز") || lower.contains("پیمانکار") -> LeadCategory.BUILDER
            lower.contains("فروش") || lower.contains("فروشنده") || lower.contains("واگذار") ||
                    lower.contains("آپارتمان") || lower.contains("ویلا") || lower.contains("مالک") -> LeadCategory.SELLER
            lower.contains("خریدار") || lower.contains("متقاضی") || lower.contains("پیش خرید") ||
                    lower.contains("سرمایه گذار") || lower.contains("بودجه") -> LeadCategory.BUYER
            lower.contains("املاک") || lower.contains("مشاور") || lower.contains("دفتر") ||
                    lower.contains("مسکن") -> LeadCategory.CONSULTANT
            else -> fallback
        }
    }

    fun formatPhone(phone: String): String {
        return if (phone.length == 11 && phone.startsWith("09")) {
            "${phone.substring(0, 4)} ${phone.substring(4, 7)} ${phone.substring(7)}"
        } else {
            phone
        }
    }
}
