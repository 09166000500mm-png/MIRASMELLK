package com.example.util

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast

object SmsHelper {

    fun sendSingleSms(context: Context, phoneNumber: String, messageText: String) {
        try {
            val uri = Uri.parse("smsto:${phoneNumber.trim()}")
            val intent = Intent(Intent.ACTION_SENDTO, uri).apply {
                putExtra("sms_body", messageText)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "برنامه ارسال پیامک یافت نشد", Toast.LENGTH_SHORT).show()
        }
    }

    fun sendBatchSms(context: Context, phoneNumbers: List<String>, messageText: String) {
        if (phoneNumbers.isEmpty()) {
            Toast.makeText(context, "هیچ شماره تماسی انتخاب نشده است", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            // Android uses semicolon or comma depending on the OEM SMS client
            val recipients = phoneNumbers.joinToString(";")
            val uri = Uri.parse("smsto:$recipients")
            val intent = Intent(Intent.ACTION_SENDTO, uri).apply {
                putExtra("sms_body", messageText)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            // Fallback to sending to first contact
            sendSingleSms(context, phoneNumbers.first(), messageText)
        }
    }

    fun dialPhone(context: Context, phoneNumber: String) {
        try {
            val uri = Uri.parse("tel:${phoneNumber.trim()}")
            val intent = Intent(Intent.ACTION_DIAL, uri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "برنامه تماس یافت نشد", Toast.LENGTH_SHORT).show()
        }
    }

    fun copyToClipboard(context: Context, label: String, text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        val clip = ClipData.newPlainText(label, text)
        clipboard?.setPrimaryClip(clip)
        Toast.makeText(context, "$label کپی شد", Toast.LENGTH_SHORT).show()
    }
}
