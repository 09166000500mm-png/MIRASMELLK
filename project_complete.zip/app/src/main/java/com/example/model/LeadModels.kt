package com.example.model

enum class LeadCategory(
    val titleFa: String,
    val descriptionFa: String,
    val emoji: String
) {
    BUILDER(
        titleFa = "سازنده و انبوه‌ساز",
        descriptionFa = "پروژه‌های در حال ساخت، مشارکت در ساخت، زمین کلنگی",
        emoji = "🏗️"
    ),
    SELLER(
        titleFa = "فروشنده ملک",
        descriptionFa = "آپارتمان، ویلا، مستغلات، زمین و کلنگی",
        emoji = "🏠"
    ),
    BUYER(
        titleFa = "خریدار و متقاضی",
        descriptionFa = "خریداران نقدی، سرمایه‌گذاران، متقاضیان پیش‌خرید",
        emoji = "🔑"
    ),
    CONSULTANT(
        titleFa = "مشاور و دفتر املاک",
        descriptionFa = "همکاران صنفی و دفاتر معاملات ملکی منطقه",
        emoji = "🏢"
    );

    companion object {
        fun fromString(value: String): LeadCategory {
            return entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: SELLER
        }
    }
}

enum class LeadStatus(
    val titleFa: String,
    val colorHex: Long
) {
    NEW(titleFa = "جدید", colorHex = 0xFF2563EB),           // Blue
    SMS_SENT(titleFa = "پیامک ارسال شد", colorHex = 0xFF7C3AED), // Purple
    CONTACTED(titleFa = "تماس تلفنی", colorHex = 0xFFD97706),   // Amber
    INTERESTED(titleFa = "علاقه‌مند و پیگیر", colorHex = 0xFF059669), // Green
    CLOSED(titleFa = "معامله موفق", colorHex = 0xFF10B981);       // Emerald

    companion object {
        fun fromString(value: String): LeadStatus {
            return entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: NEW
        }
    }
}

data class CampaignTemplate(
    val id: String,
    val title: String,
    val category: LeadCategory,
    val messageText: String
)
