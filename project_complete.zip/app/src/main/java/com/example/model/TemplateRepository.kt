package com.example.model

object TemplateRepository {

    val defaultTemplates: List<CampaignTemplate> = listOf(
        // Builders Templates
        CampaignTemplate(
            id = "t_builder_1",
            title = "پیشنهاد مشارکت در ساخت به سازندگان",
            category = LeadCategory.BUILDER,
            messageText = "سلام جناب مهندس {نام} محترم، زمین کلنگی با موقعیت عالی و بر مناسب در {منطقه} {شهر} آماده مشارکت با سازندگان معتبر می‌باشد. جهت دریافت اطلاعات و شرایط لطفاً تماس حاصل فرمایید."
        ),
        CampaignTemplate(
            id = "t_builder_2",
            title = "معرفی خریداران نقدی برای پیش‌فروش",
            category = LeadCategory.BUILDER,
            messageText = "درود بر شما سازنده گرامی، خریداران نقدی با بودجه آماده جهت پیش‌خرید پروژه‌های باکیفیت در {منطقه} موجود هستند. در صورت تمایل به فروش سریع واحدهایتان پاسخ دهید."
        ),

        // Sellers Templates
        CampaignTemplate(
            id = "t_seller_1",
            title = "فروش فوری ملک با خریدار آماده",
            category = LeadCategory.SELLER,
            messageText = "مالک گرامی در {منطقه} {شهر}، خریدار نقدی واقعی با تاییدیه مالی آماده معامله ملک شما با بالاترین قیمت کارشناسی روز می‌باشد. جهت هماهنگی بازدید لطفاً تماس بگیرید."
        ),
        CampaignTemplate(
            id = "t_seller_2",
            title = "مشاوره و قیمت‌گذاری رایگان ملک",
            category = LeadCategory.SELLER,
            messageText = "سلام و احترام، اگر قصد تبدیل به احسن، فروش یا معاوضه ملک خود در محدوده {منطقه} را دارید، ما با قوی‌ترین فایلینگ و متقاضیان آماده در خدمت شما هستیم."
        ),

        // Buyers Templates
        CampaignTemplate(
            id = "t_buyer_1",
            title = "فرصت‌های استثنایی زیر قیمت منطقه",
            category = LeadCategory.BUYER,
            messageText = "جناب {نام} گرامی، چند فایل آپارتمان اکازیون و زیر قیمت بازار در {منطقه} {شهر} با شرایط پرداخت بسیار جذاب موجود شده است. جهت ارسال مشخصات و بازدید اطلاع دهید."
        ),
        CampaignTemplate(
            id = "t_buyer_2",
            title = "پیش‌خرید مطمئن از سازندگان بنام",
            category = LeadCategory.BUYER,
            messageText = "فرصت بی‌نظیر پیش‌خرید واحدهای لوکس در {منطقه} با پیشرفت فیزیکی بالا، سازنده برند و اقساط منعطف. برای اطلاعات تکمیلی تماس بگیرید."
        ),

        // General
        CampaignTemplate(
            id = "t_general_1",
            title = "دعوت به همکاری ملکی",
            category = LeadCategory.CONSULTANT,
            messageText = "همکار گرامی در {شهر}، آماده همکاری و تبادل فایل‌های انحصاری فروش و پیش‌فروش در {منطقه} با پورسانت و شرایط عالی هستیم. در صورت تمایل تماس حاصل فرمایید."
        )
    )

    fun formatMessage(templateText: String, name: String, district: String, city: String, phone: String = ""): String {
        return templateText
            .replace("{نام}", name.ifBlank { "همراه گرامی" })
            .replace("{منطقه}", district.ifBlank { "منطقه" })
            .replace("{شهر}", city.ifBlank { "شهر" })
            .replace("{تلفن}", phone)
    }
}
