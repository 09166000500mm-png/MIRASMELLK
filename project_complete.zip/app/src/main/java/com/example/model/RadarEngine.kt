package com.example.model

data class RadarLead(
    val id: String,
    val fullName: String,
    val phoneNumber: String,
    val category: LeadCategory,
    val province: String,
    val city: String,
    val district: String,
    val propertyTitle: String,
    val propertyDetails: String,
    val priceOrBudget: String,
    val tags: List<String>,
    val verified: Boolean = true
)

object RadarEngine {

    fun generateLeadsForLocation(
        province: String,
        city: String,
        district: String,
        categoryFilter: LeadCategory? = null
    ): List<RadarLead> {
        val targetDistrict = if (district == "همه مناطق") "مرکزی و شاخص $city" else district
        val results = mutableListOf<RadarLead>()

        // 1. Builders (سازندگان)
        val builders = listOf(
            RadarLead(
                id = "radar_b1_${province}_$city",
                fullName = "مهندس حسینی (پروژه سپهر)",
                phoneNumber = "0912" + (1000000..9999999).random().toString().take(7),
                category = LeadCategory.BUILDER,
                province = province,
                city = city,
                district = targetDistrict,
                propertyTitle = "پروژه در حال ساخت ۱۲ واحدی لوکس",
                propertyDetails = "سازه اسکلت فلزی با استاندارد بالا، در مرحله نازک‌کاری و سفت‌کاری، نیازمند متریال و پیش‌فروش واحدها",
                priceOrBudget = "متری ۸۵ تا ۱۲۰ میلیون تومان",
                tags = listOf("پیش‌فروش", "سازنده برند", "سند ملکی")
            ),
            RadarLead(
                id = "radar_b2_${province}_$city",
                fullName = "گروه توسعه ابنیه پارسیان",
                phoneNumber = "0912" + (1000000..9999999).random().toString().take(7),
                category = LeadCategory.BUILDER,
                province = province,
                city = city,
                district = targetDistrict,
                propertyTitle = "متقاضی زمین کلنگی جهت مشارکت",
                propertyDetails = "آماده مشارکت در ساخت با مالکین محترم، تامین بالاترین درصد سهم مالک و بلاعوض، دارای نمونه کارهای تحویل‌شده",
                priceOrBudget = "بودجه ساخت نامحدود + بلاعوض نقدی",
                tags = listOf("مشارکت در ساخت", "بلاعوض", "پیمانکاری")
            ),
            RadarLead(
                id = "radar_b3_${province}_$city",
                fullName = "مهندس مرادی (سازنده اختصاصی)",
                phoneNumber = "0935" + (1000000..9999999).random().toString().take(7),
                category = LeadCategory.BUILDER,
                province = province,
                city = city,
                district = targetDistrict,
                propertyTitle = "پیش‌فروش پنت‌هاوس و طبقات بالا",
                propertyDetails = "دارای ۳ خواب مستر، تراس گاردن اختصاصی، ۲ لاین آسانسور، لابی مجلل و سالن اجتماعات",
                priceOrBudget = "شرایط اقساطی متناسب با پیشرفت پروژه",
                tags = listOf("پنت‌هاوس", "فول مشاعات", "روف‌گاردن")
            )
        )

        // 2. Sellers (فروشندگان ملک)
        val sellers = listOf(
            RadarLead(
                id = "radar_s1_${province}_$city",
                fullName = "آقای یزدانی (مالک شخصی)",
                phoneNumber = "0912" + (1000000..9999999).random().toString().take(7),
                category = LeadCategory.SELLER,
                province = province,
                city = city,
                district = targetDistrict,
                propertyTitle = "فروش فوری آپارتمان ۱۳۵ متری ۳ خوابه",
                propertyDetails = "تک‌واحدی، طبقه ۴ با نورگیر عالی شمال و جنوب، پارکینگ سندی بدون مزاحم، انباری بزرگ، آماده تخلیه",
                priceOrBudget = "زیر قیمت کارشناسی منطقه (تخفیف نقدی)",
                tags = listOf("تک‌واحدی", "سند آماده انتقال", "فوری")
            ),
            RadarLead(
                id = "radar_s2_${province}_$city",
                fullName = "حاج محسن داوودی",
                phoneNumber = "0919" + (1000000..9999999).random().toString().take(7),
                category = LeadCategory.SELLER,
                province = province,
                city = city,
                district = targetDistrict,
                propertyTitle = "فروش زمین کلنگی ۴۰۰ متری بر ۱۶",
                propertyDetails = "لوکیشن دنج و عریض، دستور نقشه ۵ طبقه روی پیلوت اخذ شده، مناسب سازندگان خوش‌نام",
                priceOrBudget = "قیمت توافقی یا تهاتر با واحد آماده",
                tags = listOf("کلنگی", "دستور نقشه", "بر مناسب")
            ),
            RadarLead(
                id = "radar_s3_${province}_$city",
                fullName = "خانم مهندس سعادت",
                phoneNumber = "0921" + (1000000..9999999).random().toString().take(7),
                category = LeadCategory.SELLER,
                province = province,
                city = city,
                district = targetDistrict,
                propertyTitle = "فروش واحد تجاری/اداری ۶۵ متری تابلوخور",
                propertyDetails = "سند اداری، بر خیابان اصلی با پاخور فوق‌العاده، مناسب مطب پزشکان، دفتر مهندسی یا شرکت بازرگانی",
                priceOrBudget = "امکان معاوضه با آپارتمان مسکونی",
                tags = listOf("سند اداری", "پاخور عالی", "بر اصلی")
            )
        )

        // 3. Buyers (خریداران و سرمایه‌گذاران)
        val buyers = listOf(
            RadarLead(
                id = "radar_bu1_${province}_$city",
                fullName = "دکتر شایانفر (سرمایه‌گذار)",
                phoneNumber = "0912" + (1000000..9999999).random().toString().take(7),
                category = LeadCategory.BUYER,
                province = province,
                city = city,
                district = targetDistrict,
                propertyTitle = "متقاضی خرید نقدی آپارتمان نوساز تا ۱۵۰ متر",
                propertyDetails = "خریدار واقعی با نقدینگی کامل، بدون نیاز به دریافت وام، ترجیحاً طبقات میانی با متریال باکیفیت",
                priceOrBudget = "نقدینگی آماده تا ۳۰ میلیارد تومان",
                tags = listOf("خریدار نقدی", "تسویه فوری", "بدون وام")
            ),
            RadarLead(
                id = "radar_bu2_${province}_$city",
                fullName = "مهندس فرهمند",
                phoneNumber = "0936" + (1000000..9999999).random().toString().take(7),
                category = LeadCategory.BUYER,
                province = province,
                city = city,
                district = targetDistrict,
                propertyTitle = "خریدار زمین کلنگی جهت احداث مجتمع مسکونی",
                propertyDetails = "نیازمند زمین یا کلنگی در گذرهای ۱۲ متر به بالا، با سند ششدانگ و قابلیت ساخت",
                priceOrBudget = "سرمایه اولیه آماده سرمایه‌گذاری",
                tags = listOf("خریدار کلنگی", "سازنده خریدار", "سرمایه‌گذاری")
            ),
            RadarLead(
                id = "radar_bu3_${province}_$city",
                fullName = "آقای کمالی",
                phoneNumber = "0913" + (1000000..9999999).random().toString().take(7),
                category = LeadCategory.BUYER,
                province = province,
                city = city,
                district = targetDistrict,
                propertyTitle = "متقاضی پیش‌خرید واحدهای ۲ خوابه خوش‌نقشه",
                propertyDetails = "سرمایه‌گذار جهت پیش‌خرید از سازندگان معتبر دارای سابقه ساخت و رزومه قوی در منطقه",
                priceOrBudget = "پیش‌پرداخت ۵۰٪ + اقساط ۲ ساله",
                tags = listOf("پیش‌خرید", "سرمایه‌گذاری", "۲خواب")
            )
        )

        // 4. Consultants (همکاران املاک)
        val consultants = listOf(
            RadarLead(
                id = "radar_c1_${province}_$city",
                fullName = "املاک الماس $district",
                phoneNumber = "0912" + (1000000..9999999).random().toString().take(7),
                category = LeadCategory.CONSULTANT,
                province = province,
                city = city,
                district = targetDistrict,
                propertyTitle = "دفتر معاملات تخصصی املاک و مستغلات",
                propertyDetails = "دارای فایلینگ انحصاری منطقه، آماده همکاری مستقیم با سازندگان و مالکان جهت فروش سریع",
                priceOrBudget = "شبکه گسترده خریداران آماده",
                tags = listOf("همکار صنفی", "فایلینگ قوی", "فروش سریع")
            )
        )

        val combined = builders + sellers + buyers + consultants

        return if (categoryFilter != null) {
            combined.filter { it.category == categoryFilter }
        } else {
            combined
        }
    }
}
