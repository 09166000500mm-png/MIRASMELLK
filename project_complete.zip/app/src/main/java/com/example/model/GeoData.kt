package com.example.model

data class ProvinceData(
    val name: String,
    val cities: List<CityData>
)

data class CityData(
    val name: String,
    val districts: List<String>
)

object IranGeoData {
    val provinces: List<ProvinceData> = listOf(
        ProvinceData(
            name = "تهران",
            cities = listOf(
                CityData(
                    name = "تهران",
                    districts = listOf(
                        "همه مناطق",
                        "منطقه ۱ (نیاوران، زعفرانیه، الهیه، ولنجک، تجریش)",
                        "منطقه ۲ (سعادت‌آباد، شهرک غرب، گیشا، ستارخان)",
                        "منطقه ۳ (ونک، میرداماد، جردن، پاسداران، قلهک)",
                        "منطقه ۴ (تهرانپارس، هروی، شیان، شمس‌آباد)",
                        "منطقه ۵ (پونک، جنت‌آباد، صادقیه، فردوس، باغ فیض)",
                        "منطقه ۶ (یوسف‌آباد، امیرآباد، فاطمی، توانیر)",
                        "منطقه ۷ (سهروردی، عباس‌آباد، بهار، نیلوفر)",
                        "منطقه ۸ (نارمک، مجیدیه، هفت حوض)",
                        "منطقه ۲۲ (چیتگر، دریاچه خلیج فارس، دهکده المپیک)",
                        "پردیس (فاز ۱ تا ۱۱)"
                    )
                ),
                CityData(
                    name = "دماوند و رودهن",
                    districts = listOf("همه مناطق", "گیلاوند", "مشا", "هشت بهشت", "آبعلی", "رودهن")
                ),
                CityData(
                    name = "شهریار و اندیشه",
                    districts = listOf("همه مناطق", "اندیشه فاز ۱", "اندیشه فاز ۳", "کردزار", "وحیدیه")
                )
            )
        ),
        ProvinceData(
            name = "خراسان رضوی",
            cities = listOf(
                CityData(
                    name = "مشهد",
                    districts = listOf(
                        "همه مناطق",
                        "احمدآباد و کوهسنگی",
                        "بلوار سجاد و خیام",
                        "بلوار وکیل‌آباد و کوثر",
                        "الهیه و قاسم‌آباد",
                        "هاشمیه و هنرستان",
                        "هفت تیر و صیاد شیرازی",
                        "سناباد و فلسطین",
                        "طبرسی و پیرامون حرم"
                    )
                ),
                CityData(
                    name = "نیشابور",
                    districts = listOf("همه مناطق", "مرکز شهر", "خیابان خیام", "شهرک فرهنگیان")
                ),
                CityData(
                    name = "سبزوار",
                    districts = listOf("همه مناطق", "بلوار توحید", "مرکز شهر", "شهرک توحید")
                )
            )
        ),
        ProvinceData(
            name = "اصفهان",
            cities = listOf(
                CityData(
                    name = "اصفهان",
                    districts = listOf(
                        "همه مناطق",
                        "مرداویج و پرواز",
                        "جلفا و نظر غربی",
                        "شیخ صدوق و ملاصدرا",
                        "آپادانا و آبشار",
                        "مهرآباد و مشتاق",
                        "خیابان چهارباغ بالا",
                        "خانه اصفهان و رباط",
                        "سپاهان‌شهر",
                        "شاهین‌شهر"
                    )
                ),
                CityData(
                    name = "کاشان",
                    districts = listOf("همه مناطق", "امیرکبیر", "میدان جهاد", "خیابان بهشتی")
                )
            )
        ),
        ProvinceData(
            name = "فارس",
            cities = listOf(
                CityData(
                    name = "شیراز",
                    districts = listOf(
                        "همه مناطق",
                        "معالی‌آباد و فرهنگ‌شهر",
                        "قصرالدشت و مهدی‌آباد",
                        "عفیف‌آباد و ستارخان",
                        "خاکشناسی و ارم",
                        "زرگری و مطهری",
                        "قدوسی شرقی و غربی",
                        "تاچارا و میرزای شیرازی",
                        "صدرا (فاز ۱ و ۲)"
                    )
                )
            )
        ),
        ProvinceData(
            name = "البرز",
            cities = listOf(
                CityData(
                    name = "کرج",
                    districts = listOf(
                        "همه مناطق",
                        "عظیمیه و طالقانی",
                        "مهرشهر (فاز ۱، ۲، ۳)",
                        "جهانشهر و ماهان",
                        "گوهردشت (فاز ۱، ۲، ۳)",
                        "فردیس و فلکه‌ها",
                        "گلشهر و درختی",
                        "باغستان و شاهین‌ویلا",
                        "محمدشهر و ماهدشت"
                    )
                )
            )
        ),
        ProvinceData(
            name = "خوزستان",
            cities = listOf(
                CityData(
                    name = "اهواز",
                    districts = listOf(
                        "همه مناطق",
                        "کیانپارس (خیابان‌های شرقی و غربی)",
                        "زیتون کارمندی و کارگری",
                        "کیان‌آباد و وهابی",
                        "پادادشهر و فاز ۱",
                        "گلستان و فرهنگ‌شهر",
                        "امانیه و نادری",
                        "کوی ملت (کوروش)"
                    )
                ),
                CityData(
                    name = "دزفول",
                    districts = listOf("همه مناطق", "مرکز شهر", "فرهنگ‌شهر", "کوی مهر")
                ),
                CityData(
                    name = "آبادان",
                    districts = listOf("همه مناطق", "بریم", "بوآرده", "امیری")
                )
            )
        ),
        ProvinceData(
            name = "آذربایجان شرقی",
            cities = listOf(
                CityData(
                    name = "تبریز",
                    districts = listOf(
                        "همه مناطق",
                        "ولیعصر و همافر",
                        "ایل‌گلی و شمس تبریزی",
                        "رشدیه و نصر",
                        "زعفرانیه و میرداماد",
                        "آبرسان و دانشگاه",
                        "باغمیشه و الهیه",
                        "مرکز شهر و شریعتی"
                    )
                )
            )
        ),
        ProvinceData(
            name = "مازندران",
            cities = listOf(
                CityData(
                    name = "ساری",
                    districts = listOf("همه مناطق", "خیابان قارن", "فرهنگ", "پیوندی", "طبرستان")
                ),
                CityData(
                    name = "سلمان‌شهر (متل قو) و کلارآباد",
                    districts = listOf("همه مناطق", "دریاگوشه", "برج‌های دوقلو", "ساحلی", "تیلاکنار")
                ),
                CityData(
                    name = "نوشهر و چالوس",
                    districts = listOf("همه مناطق", "سیسنگان", "هلستان", "رادیودریا", "خط هشت")
                ),
                CityData(
                    name = "بابل",
                    districts = listOf("همه مناطق", "خیابان مدرس", "میدان ولایت", "امیرکبیر")
                )
            )
        ),
        ProvinceData(
            name = "گیلان",
            cities = listOf(
                CityData(
                    name = "رشت",
                    districts = listOf("همه مناطق", "گلسار و بلوار سمیه", "منظریه", "بلوار دیلمان", "معلم", "رشتیان")
                ),
                CityData(
                    name = "بندرانزلی",
                    districts = listOf("همه مناطق", "پاسداران", "غازیان", "ساحل قو")
                ),
                CityData(
                    name = "لاهیجان",
                    districts = listOf("همه مناطق", "استخر و بام سبز", "خیابان کارگر", "شیخ زاهد")
                )
            )
        ),
        ProvinceData(
            name = "قم",
            cities = listOf(
                CityData(
                    name = "قم",
                    districts = listOf("همه مناطق", "سالاریه", "زنبیل‌آباد", "صفائیه", "بنیاد", "پردیسان")
                )
            )
        ),
        ProvinceData(
            name = "هرمزگان",
            cities = listOf(
                CityData(
                    name = "بندرعباس",
                    districts = listOf("همه مناطق", "گلشهر", "رسالت", "سیم‌بالا", "ساحلی")
                ),
                CityData(
                    name = "کیش",
                    districts = listOf("همه مناطق", "شهرک صدف", "دامون", "مرجان", "میرمهنا")
                )
            )
        )
    )

    fun getProvince(name: String): ProvinceData? = provinces.find { it.name == name }
}
