package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface LeadDao {

    @Query("SELECT * FROM leads ORDER BY id DESC")
    fun getAllLeads(): Flow<List<LeadEntity>>

    @Query("SELECT * FROM leads WHERE category = :category ORDER BY id DESC")
    fun getLeadsByCategory(category: String): Flow<List<LeadEntity>>

    @Query("SELECT * FROM leads WHERE province = :province AND (:city IS NULL OR city = :city) ORDER BY id DESC")
    fun getLeadsByLocation(province: String, city: String?): Flow<List<LeadEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLead(lead: LeadEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLeads(leads: List<LeadEntity>): List<Long>

    @Update
    suspend fun updateLead(lead: LeadEntity)

    @Delete
    suspend fun deleteLead(lead: LeadEntity)

    @Query("DELETE FROM leads WHERE id = :id")
    suspend fun deleteLeadById(id: Long)

    @Query("DELETE FROM leads")
    suspend fun deleteAllLeads()

    @Query("UPDATE leads SET status = :status, lastContactedAt = :timestamp WHERE id = :id")
    suspend fun updateStatus(id: Long, status: String, timestamp: Long)

    @Query("SELECT COUNT(*) FROM leads")
    fun getCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM leads WHERE category = :category")
    fun getCountByCategory(category: String): Flow<Int>
}
