package com.example.data

import com.example.model.LeadCategory
import com.example.model.LeadStatus
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class LeadRepository(private val dao: LeadDao) {

    val allLeads: Flow<List<LeadEntity>> = dao.getAllLeads()
    val totalCount: Flow<Int> = dao.getCount()

    suspend fun insertLead(lead: LeadEntity): Long = dao.insertLead(lead)

    suspend fun insertLeads(leads: List<LeadEntity>): List<Long> = dao.insertLeads(leads)

    suspend fun updateLead(lead: LeadEntity) = dao.updateLead(lead)

    suspend fun deleteLead(lead: LeadEntity) = dao.deleteLead(lead)

    suspend fun deleteLeadById(id: Long) = dao.deleteLeadById(id)

    suspend fun deleteAll() = dao.deleteAllLeads()

    suspend fun markContacted(id: Long, isSms: Boolean) {
        val status = if (isSms) LeadStatus.SMS_SENT else LeadStatus.CONTACTED
        dao.updateStatus(id, status.name, System.currentTimeMillis())
    }

    suspend fun seedInitialDataIfEmpty() {
        val count = dao.getCount().first()
        if (count == 0) {
            val sampleLeads = listOf(
                LeadEntity(
                    fullName = "مهندس کامران رستمی",
                    phoneNumber = "09121118492",
                    category = LeadCategory.BUILDER,
                    province = "تهران",
                    city = "تهران",
                    district = "منطقه ۱ (نیاوران، زعفرانیه، الهیه، ولنجک، تجریش)",
                    propertyDetails = "سازنده ۵ پروژه لوکس در زعفرانیه و فرمانیه، نیازمند زمین کلنگی بالای ۵۰۰ متر جهت مشارکت",
                    status = LeadStatus.NEW,
                    source = "کاوشگر املاک",
                    notes = "پروژه‌های قبلی در الهیه و ولنجک تحویل داده شده"
                ),
                LeadEntity(
                    fullName = "حاج اصغر کریمی (مالک)",
                    phoneNumber = "09122349015",
                    category = LeadCategory.SELLER,
                    province = "تهران",
                    city = "تهران",
                    district = "منطقه ۲ (سعادت‌آباد، شهرک غرب، گیشا، ستارخان)",
                    propertyDetails = "فروش کلنگی جنوبی ۶۰۰ متری بر ۲۰ در سعادت‌آباد، مناسب برج‌باغ و مشارکت",
                    status = LeadStatus.NEW,
                    source = "کاوشگر املاک",
                    notes = "سند تک‌برگ شخصی، ریشه شاهنشاهی ندارد"
                ),
                LeadEntity(
                    fullName = "دکتر وحید باقری",
                    phoneNumber = "09127891234",
                    category = LeadCategory.BUYER,
                    province = "تهران",
                    city = "تهران",
                    district = "منطقه ۱ (نیاوران، زعفرانیه، الهیه، ولنجک، تجریش)",
                    propertyDetails = "خریدار نقدی پنت‌هاوس بالای ۲۵۰ متر با ویو ابدی در نیاوران یا کامرانیه، بودجه تا ۱۰۰ میلیارد",
                    status = LeadStatus.INTERESTED,
                    source = "ثبت مستقیم",
                    notes = "پرداخت نقدی بدون تهاتر"
                ),
                LeadEntity(
                    fullName = "گروه ساختمانی مهندسی آرین",
                    phoneNumber = "09151249876",
                    category = LeadCategory.BUILDER,
                    province = "خراسان رضوی",
                    city = "مشهد",
                    district = "بلوار سجاد و خیام",
                    propertyDetails = "انبوه‌ساز برتر در سجاد و احمدآباد، آماده عقد قرارداد مشارکت در ساخت با درصد توافقی",
                    status = LeadStatus.NEW,
                    source = "کاوشگر املاک",
                    notes = "تضمین متریال درجه یک و بلاعوض منصفانه"
                ),
                LeadEntity(
                    fullName = "مهندس علیرضا سلیمانی",
                    phoneNumber = "09133156780",
                    category = LeadCategory.BUILDER,
                    province = "اصفهان",
                    city = "اصفهان",
                    district = "مرداویج و پرواز",
                    propertyDetails = "پروژه در حال احداث مسکونی لوکس ۱۰ واحدی، فروش واحدهای ۱۸۰ متری پیش‌خرید",
                    status = LeadStatus.NEW,
                    source = "کاوشگر املاک",
                    notes = "تحویل ۱۸ ماهه، پیشرفت ۴۰ درصدی"
                ),
                LeadEntity(
                    fullName = "مهندس نیما اعتمادی",
                    phoneNumber = "09173045612",
                    category = LeadCategory.SELLER,
                    province = "فارس",
                    city = "شیراز",
                    district = "معالی‌آباد و فرهنگ‌شهر",
                    propertyDetails = "فروش فوری آپارتمان ۱۶۵ متری تک‌واحدی صفر کلیدنخورده در فرهنگ‌شهر",
                    status = LeadStatus.NEW,
                    source = "کاوشگر املاک",
                    notes = "تخفیف عالی پای قرارداد"
                ),
                LeadEntity(
                    fullName = "مهندس فرزاد میرزایی",
                    phoneNumber = "09214567890",
                    category = LeadCategory.BUILDER,
                    province = "البرز",
                    city = "کرج",
                    district = "عظیمیه و طالقانی",
                    propertyDetails = "سازنده مجتمع تجاری-اداری در میدان اسبی عظیمیه، جذب سرمایه‌گذار و پیش‌فروش",
                    status = LeadStatus.NEW,
                    source = "استخراج هوشمند",
                    notes = "دارای پروانه ساخت معتبر شهرداری"
                ),
                LeadEntity(
                    fullName = "آقای رضایی (سرمایه‌گذار)",
                    phoneNumber = "09356789123",
                    category = LeadCategory.BUYER,
                    province = "تهران",
                    city = "تهران",
                    district = "منطقه ۵ (پونک، جنت‌آباد، صادقیه، فردوس، باغ فیض)",
                    propertyDetails = "خریدار ۳ واحد آپارتمان نوساز تا متراژ ۱۰۰ متر جهت سرمایه‌گذاری ملکی و اجاره‌داری",
                    status = LeadStatus.NEW,
                    source = "استخراج هوشمند",
                    notes = "تسویه ۲۰ روزه"
                )
            )
            dao.insertLeads(sampleLeads)
        }
    }
}
