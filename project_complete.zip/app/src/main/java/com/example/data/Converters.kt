package com.example.data

import androidx.room.TypeConverter
import com.example.model.LeadCategory
import com.example.model.LeadStatus

class Converters {
    @TypeConverter
    fun fromCategory(category: LeadCategory): String = category.name

    @TypeConverter
    fun toCategory(value: String): LeadCategory = LeadCategory.fromString(value)

    @TypeConverter
    fun fromStatus(status: LeadStatus): String = status.name

    @TypeConverter
    fun toStatus(value: String): LeadStatus = LeadStatus.fromString(value)
}
