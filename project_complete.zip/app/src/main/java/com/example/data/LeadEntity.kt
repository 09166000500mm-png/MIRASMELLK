package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.model.LeadCategory
import com.example.model.LeadStatus

@Entity(tableName = "leads")
data class LeadEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val phoneNumber: String,
    val fullName: String,
    val category: LeadCategory,
    val province: String,
    val city: String,
    val district: String,
    val propertyDetails: String,
    val status: LeadStatus = LeadStatus.NEW,
    val source: String = "استخراج هوشمند",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val lastContactedAt: Long? = null
)
