package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

/**
 * مدل داده مخاطب برای ذخیره‌سازی محلی در پایگاه داده Room
 */
@Entity(tableName = "contacts")
data class Contact(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,              // نام مخاطب یا عنوان کسب‌وکار
    val phoneNumber: String,       // شماره موبایل (مثلا 09123456789)
    val province: String,          // استان (مثلا تهران، اصفهان، خراسان رضوی)
    val district: String,          // منطقه یا محله (مثلا منطقه ۱، سعادت‌آباد، سجاد)
    val contactType: String,       // نوع مخاطب: سازنده، فروشنده ملک، خریدار، مشاور املاک
    val notes: String = "",        // توضیحات و یادداشت تکمیلی
    val createdAt: Long = System.currentTimeMillis() // تاریخ ایجاد رکورد
)

/**
 * رابط دسترسی به داده‌ها (DAO) برای انجام عملیات CRUD
 */
@Dao
interface ContactDao {

    @Query("SELECT * FROM contacts ORDER BY id DESC")
    fun getAllContacts(): Flow<List<Contact>>

    @Query("SELECT * FROM contacts WHERE contactType = :type ORDER BY id DESC")
    fun getContactsByType(type: String): Flow<List<Contact>>

    @Query("SELECT * FROM contacts WHERE province = :province AND district = :district ORDER BY id DESC")
    fun getContactsByLocation(province: String, district: String): Flow<List<Contact>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertContact(contact: Contact): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertContacts(contacts: List<Contact>): List<Long>

    @Update
    suspend fun updateContact(contact: Contact)

    @Delete
    suspend fun deleteContact(contact: Contact)

    @Query("DELETE FROM contacts WHERE id = :id")
    suspend fun deleteContactById(id: Long)

    @Query("SELECT COUNT(*) FROM contacts")
    fun getContactsCount(): Flow<Int>
}
