package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.IranGeoData
import com.example.model.LeadCategory
import com.example.ui.MainViewModel
import com.example.ui.theme.RealEstateEmerald
import com.example.ui.theme.RealEstateGold
import com.example.ui.theme.RealEstatePrimary
import com.example.util.ExtractedContact
import com.example.util.PhoneExtractorUtil
import com.example.util.SmsHelper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExtractorScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    val rawText by viewModel.extractorText.collectAsState()
    val extractedContacts by viewModel.extractedContacts.collectAsState()
    val extractorCategory by viewModel.extractorCategory.collectAsState()
    val extractorProvince by viewModel.extractorProvince.collectAsState()
    val extractorCity by viewModel.extractorCity.collectAsState()
    val extractorDistrict by viewModel.extractorDistrict.collectAsState()
    val importedMessage by viewModel.importedMessage.collectAsState()

    var showGeoDialog by remember { mutableStateOf(false) }

    val sampleAdText = """
        فروش آپارتمان ۱۸۰ متری سعادت آباد سازنده مهندس طاهری: 09123456789
        مشارکت در ساخت زمین ۵۰۰ متری نیاوران، انبوه‌ساز تماس بگیرد: ۰۹۱۲۸۷۶۵۴۳۲
        خریدار نقدی پنت‌هاوس در کامرانیه دکتر راد: +989121112233
        فروشنده ویلا لواسان آقای کمالی: 09355554433
        پیش‌خرید واحد‌های برج چیتگر دفتر فروش: ۰۹۹۰۱۲۳۴۵۶۷
        سازنده مجتمع مسکونی مهرشهر کرج مهندس سلیمی: 09126667788
    """.trimIndent()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("extractor_screen"),
        contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 90.dp)
    ) {
        // Banner Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.4f)
                )
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(RealEstateGold),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.Bolt,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column {
                        Text(
                            text = "موتور استخراج هوشمند شماره تماس",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        Text(
                            text = "استخراج سریع شماره‌های موبایل ایران از هر متن، آگهی یا کانال",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Import Success Alert
        if (importedMessage != null) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp),
                    colors = CardDefaults.cardColors(containerColor = RealEstateEmerald.copy(alpha = 0.15f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = RealEstateEmerald)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = importedMessage!!,
                            color = RealEstateEmerald,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        // Text Input Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "متن حاوی شماره‌ها را وارد یا الصاق کنید:",
                            fontWeight = FontWeight.Medium,
                            fontSize = 14.sp
                        )

                        Row {
                            TextButton(
                                onClick = {
                                    val clip = clipboardManager.getText()?.text
                                    if (!clip.isNullOrBlank()) {
                                        viewModel.setExtractorText(clip)
                                    }
                                }
                            ) {
                                Icon(Icons.Default.ContentPaste, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("پیست (Paste)", fontSize = 12.sp)
                            }

                            if (rawText.isNotBlank()) {
                                IconButton(onClick = { viewModel.clearExtractor() }) {
                                    Icon(Icons.Default.Clear, contentDescription = "پاک کردن", modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }

                    OutlinedTextField(
                        value = rawText,
                        onValueChange = { viewModel.setExtractorText(it) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                            .testTag("extractor_input_field"),
                        placeholder = {
                            Text(
                                "متن آگهی‌ها، لیست پیامک‌ها، متن کانال‌های تلگرام املاک یا فایل‌های متنی را اینجا پیست کنید...",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.outline
                            )
                        },
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Sample Data Button
                    OutlinedButton(
                        onClick = { viewModel.setExtractorText(sampleAdText) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.AutoFixHigh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("درج متن نمونه آگهی‌های واقعی جهت تست", fontSize = 12.sp)
                    }
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Tagging & Target Assignment Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "دسته‌بندی و موقعیت هدف برای شماره‌های استخراج‌شده:",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Category selection
                    Text(text = "گروه مخاطب:", fontSize = 12.sp, color = MaterialTheme.colorScheme.outline)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        LeadCategory.entries.forEach { cat ->
                            val isSelected = extractorCategory == cat
                            FilterChip(
                                selected = isSelected,
                                onClick = { viewModel.setExtractorCategory(cat) },
                                label = { Text("${cat.emoji} ${cat.titleFa}", fontSize = 11.sp) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Location target button
                    OutlinedButton(
                        onClick = { showGeoDialog = true },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Place, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "منطقه هدف: $extractorProvince / $extractorCity / $extractorDistrict",
                            fontSize = 12.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Stats & Batch Save Bar
        if (extractedContacts.isNotEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = RealEstatePrimary.copy(alpha = 0.08f)
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "تعداد شماره‌های استخراج‌شده:",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Badge(
                                containerColor = RealEstatePrimary,
                                contentColor = Color.White
                            ) {
                                Text(
                                    "${extractedContacts.size} شماره معتبر",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = { viewModel.insertAllExtractedContacts() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("import_all_contacts_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = RealEstateEmerald)
                        ) {
                            Icon(Icons.Default.GroupAdd, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                "افزودن همه (${extractedContacts.size} شماره) به بانک مخاطبان",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(14.dp))
            }

            // Extracted items list
            items(extractedContacts) { contact ->
                ExtractedContactCard(
                    contact = contact,
                    onCall = { SmsHelper.dialPhone(context, contact.canonicalPhone) },
                    onSms = {
                        val msg = "سلام و احترام، در رابطه با آگهی ملکی پیام می‌دهم."
                        SmsHelper.sendSingleSms(context, contact.canonicalPhone, msg)
                    },
                    onCopy = { SmsHelper.copyToClipboard(context, "شماره", contact.canonicalPhone) }
                )
            }
        }
    }

    // Geo Target Picker Dialog
    if (showGeoDialog) {
        AlertDialog(
            onDismissRequest = { showGeoDialog = false },
            title = { Text("تنظیم منطقه هدف برای شماره‌های جدید") },
            text = {
                Column {
                    Text("استان‌های پیشنهادی جهت انتساب:")
                    Spacer(modifier = Modifier.height(8.dp))
                    LazyColumn(modifier = Modifier.heightIn(max = 280.dp)) {
                        items(IranGeoData.provinces) { prov ->
                            ListItem(
                                headlineContent = { Text(prov.name) },
                                supportingContent = { Text("${prov.cities.size} شهر فعال") },
                                leadingContent = {
                                    Icon(Icons.Default.LocationCity, contentDescription = null)
                                },
                                modifier = Modifier
                                    .clickable {
                                        val city = prov.cities.first()
                                        val dist = city.districts.first()
                                        viewModel.setExtractorLocation(prov.name, city.name, dist)
                                        showGeoDialog = false
                                    }
                                    .padding(vertical = 2.dp)
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showGeoDialog = false }) { Text("انصراف") }
            }
        )
    }
}

@Composable
fun ExtractedContactCard(
    contact: ExtractedContact,
    onCall: () -> Unit,
    onSms: () -> Unit,
    onCopy: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = contact.detectedName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = RealEstateGold.copy(alpha = 0.15f)
                    ) {
                        Text(
                            text = contact.suggestedCategory.titleFa,
                            fontSize = 10.sp,
                            color = RealEstateGold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = PhoneExtractorUtil.formatPhone(contact.canonicalPhone),
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.primary
                )

                if (contact.contextSnippet.isNotBlank()) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = contact.contextSnippet,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.outline,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                IconButton(onClick = onCopy, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Outlined.ContentCopy, contentDescription = "کپی", modifier = Modifier.size(16.dp))
                }
                FilledTonalIconButton(onClick = onCall, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Default.Call, contentDescription = "تماس", tint = RealEstateEmerald, modifier = Modifier.size(16.dp))
                }
                FilledTonalIconButton(onClick = onSms, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Default.Sms, contentDescription = "پیامک", tint = RealEstatePrimary, modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}
