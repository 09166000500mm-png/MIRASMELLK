package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Real Estate Navy & Gold Theme
val RealEstateNavy = Color(0xFF0F172A)
val RealEstateBlue = Color(0xFF1E3A8A)
val RealEstatePrimary = Color(0xFF1D4ED8)
val RealEstatePrimaryLight = Color(0xFFDBEAFE)

val RealEstateGold = Color(0xFFD97706)
val RealEstateGoldLight = Color(0xFFFEF3C7)

val RealEstateEmerald = Color(0xFF059669)
val RealEstateEmeraldLight = Color(0xFFD1FAE5)

val Slate900 = Color(0xFF0F172A)
val Slate800 = Color(0xFF1E293B)
val Slate700 = Color(0xFF334155)
val Slate600 = Color(0xFF475569)
val Slate200 = Color(0xFFE2E8F0)
val Slate100 = Color(0xFFF1F5F9)
val Slate50 = Color(0xFFF8FAFC)

val RealEstateDarkSurface = Color(0xFF131D31)
val RealEstateDarkBackground = Color(0xFF0A0F1D)
