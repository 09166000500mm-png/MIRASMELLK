package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.LeadEntity
import com.example.model.LeadCategory
import com.example.model.LeadStatus
import com.example.ui.MainViewModel
import com.example.ui.theme.RealEstateEmerald
import com.example.ui.theme.RealEstateGold
import com.example.ui.theme.RealEstatePrimary
import com.example.util.PhoneExtractorUtil
import com.example.util.SmsHelper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LeadsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val leads by viewModel.filteredLeads.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val crmCategoryFilter by viewModel.crmCategoryFilter.collectAsState()
    val crmStatusFilter by viewModel.crmStatusFilter.collectAsState()

    var showAddDialog by remember { mutableStateOf(false) }
    var leadToChangeStatus by remember { mutableStateOf<LeadEntity?>(null) }
    var leadToDelete by remember { mutableStateOf<LeadEntity?>(null) }

    Scaffold(
        modifier = modifier.testTag("leads_screen"),
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = RealEstatePrimary,
                contentColor = Color.White,
                modifier = Modifier
                    .padding(bottom = 70.dp)
                    .testTag("add_lead_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "افزودن مخاطب")
            }
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 100.dp)
        ) {
            // Search Bar
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.setSearchQuery(it) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("leads_search_field"),
                    placeholder = { Text("جستجو در نام، شماره، منطقه یا جزئیات ملک...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.setSearchQuery("") }) {
                                Icon(Icons.Default.Close, contentDescription = "پاک کردن")
                            }
                        }
                    },
                    shape = RoundedCornerShape(16.dp),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(10.dp))
            }

            // Category Filter Chips
            item {
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        FilterChip(
                            selected = crmCategoryFilter == null,
                            onClick = { viewModel.setCrmCategoryFilter(null) },
                            label = { Text("همه دسته‌ها") }
                        )
                    }
                    items(LeadCategory.entries) { cat ->
                        FilterChip(
                            selected = crmCategoryFilter == cat,
                            onClick = { viewModel.setCrmCategoryFilter(cat) },
                            label = { Text("${cat.emoji} ${cat.titleFa}") }
                        )
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
            }

            // Status Filter Chips
            item {
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        FilterChip(
                            selected = crmStatusFilter == null,
                            onClick = { viewModel.setCrmStatusFilter(null) },
                            label = { Text("همه وضعیت‌ها") }
                        )
                    }
                    items(LeadStatus.entries) { status ->
                        FilterChip(
                            selected = crmStatusFilter == status,
                            onClick = { viewModel.setCrmStatusFilter(status) },
                            label = { Text(status.titleFa) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(status.colorHex).copy(alpha = 0.2f),
                                selectedLabelColor = Color(status.colorHex)
                            )
                        )
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Stats Count Header
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "بانک مخاطبان ملکی شما",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                    Text(
                        text = "${leads.size} مخاطب فعال",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            if (leads.isEmpty()) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 40.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            Icons.Outlined.ContactPhone,
                            contentDescription = null,
                            modifier = Modifier.size(64.dp),
                            tint = MaterialTheme.colorScheme.outline
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "هیچ مخاطبی با این مشخصات یافت نشد",
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.outline
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "از بخش «کاوشگر» یا «استخراج هوشمند» مخاطب اضافه کنید",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.outline
                        )
                    }
                }
            } else {
                items(leads, key = { it.id }) { lead ->
                    CrmLeadCard(
                        lead = lead,
                        onCall = {
                            viewModel.markLeadContacted(lead.id, isSms = false)
                            SmsHelper.dialPhone(context, lead.phoneNumber)
                        },
                        onSms = {
                            viewModel.markLeadContacted(lead.id, isSms = true)
                            val message = "سلام جناب ${lead.fullName}، در خصوص ملک شما در ${lead.district} پیام می‌دهم."
                            SmsHelper.sendSingleSms(context, lead.phoneNumber, message)
                        },
                        onCopy = {
                            SmsHelper.copyToClipboard(context, "شماره تماس", lead.phoneNumber)
                        },
                        onChangeStatus = {
                            leadToChangeStatus = lead
                        },
                        onDelete = {
                            leadToDelete = lead
                        }
                    )
                }
            }
        }
    }

    // Change Status Dialog
    if (leadToChangeStatus != null) {
        val targetLead = leadToChangeStatus!!
        AlertDialog(
            onDismissRequest = { leadToChangeStatus = null },
            title = { Text("تغییر وضعیت مخاطب: ${targetLead.fullName}") },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    LeadStatus.entries.forEach { status ->
                        ListItem(
                            headlineContent = {
                                Text(
                                    status.titleFa,
                                    color = Color(status.colorHex),
                                    fontWeight = if (targetLead.status == status) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            leadingContent = {
                                Icon(
                                    if (targetLead.status == status) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                                    contentDescription = null,
                                    tint = Color(status.colorHex)
                                )
                            },
                            modifier = Modifier
                                .clickable {
                                    viewModel.updateLeadStatus(targetLead.id, status)
                                    leadToChangeStatus = null
                                }
                                .padding(vertical = 4.dp)
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { leadToChangeStatus = null }) { Text("انصراف") }
            }
        )
    }

    // Delete Confirmation Dialog
    if (leadToDelete != null) {
        val target = leadToDelete!!
        AlertDialog(
            onDismissRequest = { leadToDelete = null },
            title = { Text("حذف مخاطب") },
            text = { Text("آیا از حذف «${target.fullName}» از بانک اطلاعاتی اطمینان دارید؟") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteLead(target)
                        leadToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("حذف")
                }
            },
            dismissButton = {
                TextButton(onClick = { leadToDelete = null }) { Text("انصراف") }
            }
        )
    }

    // Add Lead Dialog
    if (showAddDialog) {
        AddLeadDialog(
            onDismiss = { showAddDialog = false },
            onAdd = { name, phone, cat, prov, city, dist, prop, notes ->
                viewModel.addManualLead(name, phone, cat, prov, city, dist, prop, notes)
                showAddDialog = false
            }
        )
    }
}

@Composable
fun CrmLeadCard(
    lead: LeadEntity,
    onCall: () -> Unit,
    onSms: () -> Unit,
    onCopy: () -> Unit,
    onChangeStatus: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .testTag("crm_lead_card_${lead.id}"),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            // Category Badge & Status Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = when (lead.category) {
                        LeadCategory.BUILDER -> RealEstateGold.copy(alpha = 0.15f)
                        LeadCategory.SELLER -> MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                        LeadCategory.BUYER -> RealEstateEmerald.copy(alpha = 0.15f)
                        LeadCategory.CONSULTANT -> MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f)
                    }
                ) {
                    Text(
                        text = "${lead.category.emoji} ${lead.category.titleFa}",
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = when (lead.category) {
                            LeadCategory.BUILDER -> RealEstateGold
                            LeadCategory.SELLER -> MaterialTheme.colorScheme.primary
                            LeadCategory.BUYER -> RealEstateEmerald
                            LeadCategory.CONSULTANT -> MaterialTheme.colorScheme.secondary
                        }
                    )
                }

                // Clickable Status Badge
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(lead.status.colorHex).copy(alpha = 0.15f),
                    modifier = Modifier.clickable { onChangeStatus() }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = lead.status.titleFa,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(lead.status.colorHex)
                        )
                        Icon(
                            Icons.Default.ArrowDropDown,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp),
                            tint = Color(lead.status.colorHex)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Name & Phone
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = lead.fullName,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
                Text(
                    text = PhoneExtractorUtil.formatPhone(lead.phoneNumber),
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Location
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Default.LocationOn,
                    contentDescription = null,
                    modifier = Modifier.size(14.dp),
                    tint = MaterialTheme.colorScheme.outline
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "${lead.province} - ${lead.city} | ${lead.district}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.outline
                )
            }

            if (lead.propertyDetails.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = lead.propertyDetails,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 18.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
            Spacer(modifier = Modifier.height(8.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "منبع: ${lead.source}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.outline
                )

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButton(onClick = onCopy, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Outlined.ContentCopy, contentDescription = "کپی", modifier = Modifier.size(17.dp))
                    }
                    FilledTonalIconButton(onClick = onCall, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Default.Call, contentDescription = "تماس", tint = RealEstateEmerald, modifier = Modifier.size(17.dp))
                    }
                    FilledTonalIconButton(onClick = onSms, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Default.Sms, contentDescription = "پیامک", tint = RealEstatePrimary, modifier = Modifier.size(17.dp))
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Outlined.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(17.dp))
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddLeadDialog(
    onDismiss: () -> Unit,
    onAdd: (name: String, phone: String, cat: LeadCategory, prov: String, city: String, dist: String, prop: String, notes: String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var category by remember { mutableStateOf(LeadCategory.BUILDER) }
    var province by remember { mutableStateOf("تهران") }
    var city by remember { mutableStateOf("تهران") }
    var district by remember { mutableStateOf("منطقه ۱") }
    var propertyDetails by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ثبت مخاطب جدید املاک") },
        text = {
            LazyColumn(modifier = Modifier.heightIn(max = 420.dp)) {
                item {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("نام و نام خانوادگی / عنوان سازنده") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text("شماره همراه (مثلاً 09123456789)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Text("گروه مخاطب:", fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        LeadCategory.entries.forEach { cat ->
                            FilterChip(
                                selected = category == cat,
                                onClick = { category = cat },
                                label = { Text(cat.titleFa, fontSize = 10.sp) }
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = province,
                        onValueChange = { province = it },
                        label = { Text("استان") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = city,
                        onValueChange = { city = it },
                        label = { Text("شهر") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = district,
                        onValueChange = { district = it },
                        label = { Text("منطقه / محله") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = propertyDetails,
                        onValueChange = { propertyDetails = it },
                        label = { Text("مشخصات ملک یا پروژه") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("یادداشت پیگیری") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (phone.isNotBlank()) {
                        onAdd(name, phone, category, province, city, district, propertyDetails, notes)
                    }
                },
                enabled = phone.isNotBlank()
            ) {
                Text("ثبت در بانک مخاطبان")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("انصراف") }
        }
    )
}
