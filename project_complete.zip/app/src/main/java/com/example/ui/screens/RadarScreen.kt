package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.IranGeoData
import com.example.model.LeadCategory
import com.example.model.RadarLead
import com.example.ui.MainViewModel
import com.example.ui.theme.RealEstateEmerald
import com.example.ui.theme.RealEstateGold
import com.example.ui.theme.RealEstatePrimary
import com.example.util.PhoneExtractorUtil
import com.example.util.SmsHelper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RadarScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val selectedProvince by viewModel.selectedProvince.collectAsState()
    val selectedCity by viewModel.selectedCity.collectAsState()
    val selectedDistrict by viewModel.selectedDistrict.collectAsState()
    val radarCategoryFilter by viewModel.radarCategoryFilter.collectAsState()
    val radarLeads by viewModel.radarLeads.collectAsState()
    val isScanning by viewModel.isScanning.collectAsState()

    var showProvinceDialog by remember { mutableStateOf(false) }
    var showCityDialog by remember { mutableStateOf(false) }
    var showDistrictDialog by remember { mutableStateOf(false) }
    var snackbarMessage by remember { mutableStateOf<String?>(null) }

    Scaffold(
        modifier = modifier.testTag("radar_screen"),
        snackbarHost = {
            snackbarMessage?.let { msg ->
                Snackbar(
                    modifier = Modifier.padding(16.dp),
                    action = {
                        TextButton(onClick = { snackbarMessage = null }) {
                            Text("باشه", color = Color.White)
                        }
                    }
                ) {
                    Text(msg)
                }
            }
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            contentPadding = PaddingValues(bottom = 90.dp)
        ) {
            // Header Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(RealEstatePrimary),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.TravelExplore,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "کاوشگر هوشمند آگهی و فایل‌های منطقه",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 17.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "انتخاب استان، شهر و منطقه جهت استخراج سازندگان و مالکان",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Location Selectors
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = { showProvinceDialog = true },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("select_province_button"),
                                shape = RoundedCornerShape(12.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                            ) {
                                Icon(
                                    Icons.Default.LocationOn,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = selectedProvince.name,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    fontSize = 13.sp
                                )
                            }

                            OutlinedButton(
                                onClick = { showCityDialog = true },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("select_city_button"),
                                shape = RoundedCornerShape(12.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                            ) {
                                Icon(
                                    Icons.Default.Apartment,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = selectedCity.name,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    fontSize = 13.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedButton(
                            onClick = { showDistrictDialog = true },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("select_district_button"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(
                                Icons.Default.Map,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "محله / منطقه: $selectedDistrict",
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Button(
                            onClick = { viewModel.refreshRadar() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("refresh_radar_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = RealEstatePrimary)
                        ) {
                            if (isScanning) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    color = Color.White,
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("در حال اسکن و پایش منطقه...")
                            } else {
                                Icon(Icons.Default.Radar, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("اسکن و کاوش مخاطبان در این منطقه")
                            }
                        }
                    }
                }
            }

            // Category Filter Chips
            item {
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        FilterChip(
                            selected = radarCategoryFilter == null,
                            onClick = { viewModel.setRadarCategoryFilter(null) },
                            label = { Text("همه دسته‌ها (${radarLeads.size})") },
                            leadingIcon = {
                                Icon(Icons.Default.FilterList, contentDescription = null, modifier = Modifier.size(16.dp))
                            }
                        )
                    }
                    items(LeadCategory.entries) { cat ->
                        FilterChip(
                            selected = radarCategoryFilter == cat,
                            onClick = { viewModel.setRadarCategoryFilter(cat) },
                            label = { Text("${cat.emoji} ${cat.titleFa}") }
                        )
                    }
                }
            }

            // Section Header
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "نتایج استخراج شده در $selectedDistrict",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "${radarLeads.size} مورد فعال",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            // Results List
            if (radarLeads.isEmpty() && !isScanning) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(40.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            Icons.Outlined.SearchOff,
                            contentDescription = null,
                            modifier = Modifier.size(56.dp),
                            tint = MaterialTheme.colorScheme.outline
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "موردی در این دسته‌بندی یافت نشد",
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.outline
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "دکمه اسکن منطقه را لمس کنید یا دسته‌بندی را روی «همه» بگذارید",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.outline
                        )
                    }
                }
            } else {
                items(radarLeads, key = { it.id }) { lead ->
                    RadarLeadCard(
                        lead = lead,
                        onSaveToLeads = {
                            viewModel.saveRadarLeadToDatabase(lead) {
                                snackbarMessage = "شماره ${lead.fullName} در بانک مخاطبان ذخیره شد!"
                            }
                        },
                        onSendSms = {
                            val msg = "سلام جناب ${lead.fullName}، در خصوص آگهی شما (${lead.propertyTitle}) در ${lead.district} پیام می‌دهم. لطفاً در صورت تمایل به همکاری پاسخ دهید."
                            SmsHelper.sendSingleSms(context, lead.phoneNumber, msg)
                        },
                        onCall = {
                            SmsHelper.dialPhone(context, lead.phoneNumber)
                        },
                        onCopy = {
                            SmsHelper.copyToClipboard(context, "شماره تماس", lead.phoneNumber)
                        }
                    )
                }
            }
        }
    }

    // Province Picker Dialog
    if (showProvinceDialog) {
        AlertDialog(
            onDismissRequest = { showProvinceDialog = false },
            title = { Text("انتخاب استان") },
            text = {
                LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 350.dp)) {
                    items(IranGeoData.provinces) { province ->
                        ListItem(
                            headlineContent = { Text(province.name) },
                            leadingContent = {
                                Icon(Icons.Default.LocationCity, contentDescription = null)
                            },
                            modifier = Modifier
                                .clickable {
                                    viewModel.selectProvince(province)
                                    showProvinceDialog = false
                                }
                                .padding(vertical = 4.dp)
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showProvinceDialog = false }) { Text("بستن") }
            }
        )
    }

    // City Picker Dialog
    if (showCityDialog) {
        AlertDialog(
            onDismissRequest = { showCityDialog = false },
            title = { Text("انتخاب شهر در ${selectedProvince.name}") },
            text = {
                LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 350.dp)) {
                    items(selectedProvince.cities) { city ->
                        ListItem(
                            headlineContent = { Text(city.name) },
                            leadingContent = {
                                Icon(Icons.Default.Apartment, contentDescription = null)
                            },
                            modifier = Modifier
                                .clickable {
                                    viewModel.selectCity(city)
                                    showCityDialog = false
                                }
                                .padding(vertical = 4.dp)
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showCityDialog = false }) { Text("بستن") }
            }
        )
    }

    // District Picker Dialog
    if (showDistrictDialog) {
        AlertDialog(
            onDismissRequest = { showDistrictDialog = false },
            title = { Text("انتخاب منطقه / محله در ${selectedCity.name}") },
            text = {
                LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 350.dp)) {
                    items(selectedCity.districts) { district ->
                        ListItem(
                            headlineContent = {
                                Text(
                                    district,
                                    fontWeight = if (district == selectedDistrict) FontWeight.Bold else FontWeight.Normal,
                                    color = if (district == selectedDistrict) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                )
                            },
                            leadingContent = {
                                Icon(
                                    if (district == selectedDistrict) Icons.Default.CheckCircle else Icons.Default.Place,
                                    contentDescription = null,
                                    tint = if (district == selectedDistrict) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                                )
                            },
                            modifier = Modifier
                                .clickable {
                                    viewModel.selectDistrict(district)
                                    showDistrictDialog = false
                                }
                                .padding(vertical = 4.dp)
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showDistrictDialog = false }) { Text("بستن") }
            }
        )
    }
}

@Composable
fun RadarLeadCard(
    lead: RadarLead,
    onSaveToLeads: () -> Unit,
    onSendSms: () -> Unit,
    onCall: () -> Unit,
    onCopy: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .testTag("radar_lead_card_${lead.phoneNumber}"),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header Row: Category Badge & Verified
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = when (lead.category) {
                        LeadCategory.BUILDER -> RealEstateGold.copy(alpha = 0.15f)
                        LeadCategory.SELLER -> MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                        LeadCategory.BUYER -> RealEstateEmerald.copy(alpha = 0.15f)
                        LeadCategory.CONSULTANT -> MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f)
                    }
                ) {
                    Text(
                        text = "${lead.category.emoji} ${lead.category.titleFa}",
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = when (lead.category) {
                            LeadCategory.BUILDER -> RealEstateGold
                            LeadCategory.SELLER -> MaterialTheme.colorScheme.primary
                            LeadCategory.BUYER -> RealEstateEmerald
                            LeadCategory.CONSULTANT -> MaterialTheme.colorScheme.secondary
                        }
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.Verified,
                        contentDescription = "تایید شده",
                        tint = RealEstatePrimary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("آگهی فعال", fontSize = 11.sp, color = RealEstatePrimary)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Title & Name
            Text(
                text = lead.propertyTitle,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = lead.propertyDetails,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 18.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Price / Budget Tag
            Surface(
                shape = RoundedCornerShape(6.dp),
                color = MaterialTheme.colorScheme.surfaceVariant
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.MonetizationOn,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp),
                        tint = RealEstateGold
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = lead.priceOrBudget,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(10.dp))

            // Contact Info & Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = lead.fullName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Text(
                        text = PhoneExtractorUtil.formatPhone(lead.phoneNumber),
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    IconButton(
                        onClick = onCopy,
                        modifier = Modifier.size(38.dp)
                    ) {
                        Icon(
                            Icons.Outlined.ContentCopy,
                            contentDescription = "کپی شماره",
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    FilledTonalIconButton(
                        onClick = onCall,
                        modifier = Modifier.size(38.dp)
                    ) {
                        Icon(
                            Icons.Default.Call,
                            contentDescription = "تماس تلفنی",
                            tint = RealEstateEmerald,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    FilledTonalIconButton(
                        onClick = onSendSms,
                        modifier = Modifier.size(38.dp)
                    ) {
                        Icon(
                            Icons.Default.Sms,
                            contentDescription = "ارسال پیامک",
                            tint = RealEstatePrimary,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    FilledIconButton(
                        onClick = onSaveToLeads,
                        modifier = Modifier.size(38.dp),
                        colors = IconButtonDefaults.filledIconButtonColors(containerColor = RealEstatePrimary)
                    ) {
                        Icon(
                            Icons.Default.PersonAdd,
                            contentDescription = "ذخیره در مخاطبان",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}
