package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.LeadEntity
import com.example.model.LeadCategory
import com.example.model.LeadStatus
import com.example.model.TemplateRepository
import com.example.ui.MainViewModel
import com.example.ui.theme.RealEstateEmerald
import com.example.ui.theme.RealEstateGold
import com.example.ui.theme.RealEstatePrimary
import com.example.util.PhoneExtractorUtil
import com.example.util.SmsHelper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CampaignScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val allLeads by viewModel.filteredLeads.collectAsState()
    val selectedTemplate by viewModel.selectedTemplate.collectAsState()
    val customText by viewModel.campaignCustomText.collectAsState()
    val campaignCategory by viewModel.campaignCategory.collectAsState()

    // Calculate target audience
    val targetAudience = remember(allLeads, campaignCategory) {
        if (campaignCategory == null) {
            allLeads
        } else {
            allLeads.filter { it.category == campaignCategory }
        }
    }

    // Persian SMS length calculation (typically 70 chars for 1 part, 67 for concatenated)
    val charCount = customText.length
    val smsParts = if (charCount <= 70) 1 else ((charCount - 70) / 67) + 2

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("campaign_screen"),
        contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 100.dp)
    ) {
        // Top Banner
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = RealEstatePrimary.copy(alpha = 0.08f)
                )
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.Campaign,
                        contentDescription = null,
                        tint = RealEstatePrimary,
                        modifier = Modifier.size(36.dp)
                    )
                    Spacer(modifier = Modifier.width(14.dp))
                    Column {
                        Text(
                            text = "کمپین و ارسال پیامک تبلیغاتی",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        Text(
                            text = "ارسال سریع پیامک مستقیم از خط موبایل به تفکیک مخاطب هدف",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Target Group Filter
        item {
            Text(
                text = "انتخاب گروه هدف برای کمپین:",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    FilterChip(
                        selected = campaignCategory == null,
                        onClick = { viewModel.setCampaignCategory(null) },
                        label = { Text("همه مخاطبان (${allLeads.size})") }
                    )
                }
                items(LeadCategory.entries) { cat ->
                    val count = allLeads.count { it.category == cat }
                    FilterChip(
                        selected = campaignCategory == cat,
                        onClick = { viewModel.setCampaignCategory(cat) },
                        label = { Text("${cat.emoji} ${cat.titleFa} ($count)") }
                    )
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Pre-built Templates
        item {
            Text(
                text = "انتخاب قالب آماده پیامک تبلیغاتی:",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(TemplateRepository.defaultTemplates) { template ->
                    val isSelected = selectedTemplate.id == template.id
                    Card(
                        modifier = Modifier
                            .width(220.dp)
                            .clickable { viewModel.selectTemplate(template) },
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) RealEstatePrimary.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surface
                        ),
                        border = if (isSelected) CardDefaults.outlinedCardBorder() else null
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(template.category.emoji, fontSize = 14.sp)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = template.title,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = template.messageText,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Message Editor
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "متن پیامک تبلیغاتی (شخصی‌سازی شده):",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // Dynamic Tag Chips
                    Text(
                        text = "درج متغیرهای هوشمند در متن:",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.outline
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("{نام}", "{منطقه}", "{شهر}").forEach { tag ->
                            SuggestionChip(
                                onClick = {
                                    viewModel.setCampaignCustomText(customText + " " + tag)
                                },
                                label = { Text(tag, fontSize = 11.sp) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = customText,
                        onValueChange = { viewModel.setCampaignCustomText(it) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp)
                            .testTag("campaign_text_field"),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Character counter & SMS parts
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "$charCount کاراکتر ($smsParts پارت پیامک فارسی)",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.outline
                        )

                        TextButton(
                            onClick = {
                                SmsHelper.copyToClipboard(context, "متن پیامک", customText)
                            }
                        ) {
                            Icon(Icons.Outlined.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("کپی متن", fontSize = 12.sp)
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Batch Dispatch Button
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = RealEstateEmerald.copy(alpha = 0.1f)
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "جامعه هدف انتخابی:",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Badge(
                            containerColor = RealEstateEmerald,
                            contentColor = Color.White
                        ) {
                            Text(
                                "${targetAudience.size} مخاطب",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            val numbers = targetAudience.map { it.phoneNumber }
                            SmsHelper.sendBatchSms(context, numbers, customText)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("send_batch_sms_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = RealEstateEmerald),
                        enabled = targetAudience.isNotEmpty() && customText.isNotBlank()
                    ) {
                        Icon(Icons.Default.Send, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "ارسال پیامک دسته‌ای به ${targetAudience.size} مخاطب",
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedButton(
                        onClick = {
                            val phoneList = targetAudience.joinToString("\n") { "${it.fullName}: ${it.phoneNumber}" }
                            SmsHelper.copyToClipboard(context, "لیست شماره‌ها", phoneList)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        enabled = targetAudience.isNotEmpty()
                    ) {
                        Icon(Icons.Outlined.CopyAll, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("کپی لیست شماره‌های مخاطبان هدف")
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Targeted Audience Direct List
        item {
            Text(
                text = "ارسال اختصاصی با نام شخصی به تفکیک مخاطب:",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
        }

        if (targetAudience.isEmpty()) {
            item {
                Text(
                    text = "مخاطبی در این گروه یافت نشد.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.outline
                )
            }
        } else {
            items(targetAudience) { lead ->
                val personalizedMessage = TemplateRepository.formatMessage(
                    templateText = customText,
                    name = lead.fullName,
                    district = lead.district,
                    city = lead.city,
                    phone = lead.phoneNumber
                )

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = lead.fullName,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Text(
                                text = "${lead.district} | ${PhoneExtractorUtil.formatPhone(lead.phoneNumber)}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.outline
                            )
                        }

                        Button(
                            onClick = {
                                viewModel.markLeadContacted(lead.id, isSms = true)
                                SmsHelper.sendSingleSms(context, lead.phoneNumber, personalizedMessage)
                            },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (lead.status == LeadStatus.SMS_SENT) RealEstateGold else RealEstatePrimary
                            ),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (lead.status == LeadStatus.SMS_SENT) "مجدد" else "ارسال",
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
