package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.LeadEntity
import com.example.data.LeadRepository
import com.example.model.CampaignTemplate
import com.example.model.CityData
import com.example.model.IranGeoData
import com.example.model.LeadCategory
import com.example.model.LeadStatus
import com.example.model.ProvinceData
import com.example.model.RadarEngine
import com.example.model.RadarLead
import com.example.model.TemplateRepository
import com.example.util.ExtractedContact
import com.example.util.PhoneExtractorUtil
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AppScreen {
    RADAR,
    LEADS,
    EXTRACTOR,
    CAMPAIGN
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: LeadRepository

    // Screen navigation
    private val _currentScreen = MutableStateFlow(AppScreen.RADAR)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    // Location selection for Radar
    val allProvinces = IranGeoData.provinces
    private val _selectedProvince = MutableStateFlow(allProvinces.first())
    val selectedProvince: StateFlow<ProvinceData> = _selectedProvince.asStateFlow()

    private val _selectedCity = MutableStateFlow(allProvinces.first().cities.first())
    val selectedCity: StateFlow<CityData> = _selectedCity.asStateFlow()

    private val _selectedDistrict = MutableStateFlow("همه مناطق")
    val selectedDistrict: StateFlow<String> = _selectedDistrict.asStateFlow()

    private val _radarCategoryFilter = MutableStateFlow<LeadCategory?>(null)
    val radarCategoryFilter: StateFlow<LeadCategory?> = _radarCategoryFilter.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private val _radarLeads = MutableStateFlow<List<RadarLead>>(emptyList())
    val radarLeads: StateFlow<List<RadarLead>> = _radarLeads.asStateFlow()

    // Leads CRM State
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _crmCategoryFilter = MutableStateFlow<LeadCategory?>(null)
    val crmCategoryFilter: StateFlow<LeadCategory?> = _crmCategoryFilter.asStateFlow()

    private val _crmStatusFilter = MutableStateFlow<LeadStatus?>(null)
    val crmStatusFilter: StateFlow<LeadStatus?> = _crmStatusFilter.asStateFlow()

    // Raw leads from DB
    private val _rawDbLeads: StateFlow<List<LeadEntity>>

    // Filtered leads for UI
    val filteredLeads: StateFlow<List<LeadEntity>>

    // Extractor State
    private val _extractorText = MutableStateFlow("")
    val extractorText: StateFlow<String> = _extractorText.asStateFlow()

    private val _extractedContacts = MutableStateFlow<List<ExtractedContact>>(emptyList())
    val extractedContacts: StateFlow<List<ExtractedContact>> = _extractedContacts.asStateFlow()

    private val _extractorCategory = MutableStateFlow(LeadCategory.BUILDER)
    val extractorCategory: StateFlow<LeadCategory> = _extractorCategory.asStateFlow()

    private val _extractorProvince = MutableStateFlow("تهران")
    val extractorProvince: StateFlow<String> = _extractorProvince.asStateFlow()

    private val _extractorCity = MutableStateFlow("تهران")
    val extractorCity: StateFlow<String> = _extractorCity.asStateFlow()

    private val _extractorDistrict = MutableStateFlow("منطقه ۱ (نیاوران، زعفرانیه، الهیه، ولنجک، تجریش)")
    val extractorDistrict: StateFlow<String> = _extractorDistrict.asStateFlow()

    private val _importedMessage = MutableStateFlow<String?>(null)
    val importedMessage: StateFlow<String?> = _importedMessage.asStateFlow()

    // Campaign State
    private val _selectedTemplate = MutableStateFlow(TemplateRepository.defaultTemplates.first())
    val selectedTemplate: StateFlow<CampaignTemplate> = _selectedTemplate.asStateFlow()

    private val _campaignCategory = MutableStateFlow<LeadCategory?>(LeadCategory.BUILDER)
    val campaignCategory: StateFlow<LeadCategory?> = _campaignCategory.asStateFlow()

    private val _campaignProvince = MutableStateFlow("همه استان‌ها")
    val campaignProvince: StateFlow<String> = _campaignProvince.asStateFlow()

    private val _campaignCustomText = MutableStateFlow(TemplateRepository.defaultTemplates.first().messageText)
    val campaignCustomText: StateFlow<String> = _campaignCustomText.asStateFlow()

    init {
        val db = AppDatabase.getDatabase(application)
        repository = LeadRepository(db.leadDao())

        _rawDbLeads = repository.allLeads.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        filteredLeads = combine(
            _rawDbLeads,
            _searchQuery,
            _crmCategoryFilter,
            _crmStatusFilter
        ) { leads, query, cat, stat ->
            leads.filter { lead ->
                val matchesQuery = query.isBlank() ||
                        lead.fullName.contains(query, ignoreCase = true) ||
                        lead.phoneNumber.contains(query) ||
                        lead.district.contains(query, ignoreCase = true) ||
                        lead.propertyDetails.contains(query, ignoreCase = true) ||
                        lead.notes.contains(query, ignoreCase = true)

                val matchesCat = cat == null || lead.category == cat
                val matchesStat = stat == null || lead.status == stat

                matchesQuery && matchesCat && matchesStat
            }
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        viewModelScope.launch {
            repository.seedInitialDataIfEmpty()
            refreshRadar()
        }
    }

    fun navigateTo(screen: AppScreen) {
        _currentScreen.value = screen
    }

    // --- Radar Actions ---
    fun selectProvince(province: ProvinceData) {
        _selectedProvince.value = province
        _selectedCity.value = province.cities.first()
        _selectedDistrict.value = province.cities.first().districts.first()
        refreshRadar()
    }

    fun selectCity(city: CityData) {
        _selectedCity.value = city
        _selectedDistrict.value = city.districts.first()
        refreshRadar()
    }

    fun selectDistrict(district: String) {
        _selectedDistrict.value = district
        refreshRadar()
    }

    fun setRadarCategoryFilter(cat: LeadCategory?) {
        _radarCategoryFilter.value = cat
        refreshRadar()
    }

    fun refreshRadar() {
        viewModelScope.launch {
            _isScanning.value = true
            delay(400) // smooth UX feel
            _radarLeads.value = RadarEngine.generateLeadsForLocation(
                province = _selectedProvince.value.name,
                city = _selectedCity.value.name,
                district = _selectedDistrict.value,
                categoryFilter = _radarCategoryFilter.value
            )
            _isScanning.value = false
        }
    }

    fun saveRadarLeadToDatabase(radarLead: RadarLead, onComplete: () -> Unit) {
        viewModelScope.launch {
            val entity = LeadEntity(
                fullName = radarLead.fullName,
                phoneNumber = radarLead.phoneNumber,
                category = radarLead.category,
                province = radarLead.province,
                city = radarLead.city,
                district = radarLead.district,
                propertyDetails = "${radarLead.propertyTitle}: ${radarLead.propertyDetails} | ${radarLead.priceOrBudget}",
                status = LeadStatus.NEW,
                source = "کاوشگر املاک",
                notes = "برچسب‌ها: ${radarLead.tags.joinToString("، ")}"
            )
            repository.insertLead(entity)
            onComplete()
        }
    }

    // --- CRM Actions ---
    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setCrmCategoryFilter(cat: LeadCategory?) {
        _crmCategoryFilter.value = cat
    }

    fun setCrmStatusFilter(status: LeadStatus?) {
        _crmStatusFilter.value = status
    }

    fun addManualLead(
        fullName: String,
        phoneNumber: String,
        category: LeadCategory,
        province: String,
        city: String,
        district: String,
        propertyDetails: String,
        notes: String
    ) {
        viewModelScope.launch {
            val formatted = PhoneExtractorUtil.normalizeDigits(phoneNumber).replace(Regex("""[\s\-]"""), "")
            val entity = LeadEntity(
                fullName = fullName.ifBlank { "مخاطب جدید" },
                phoneNumber = formatted,
                category = category,
                province = province,
                city = city,
                district = district,
                propertyDetails = propertyDetails,
                status = LeadStatus.NEW,
                source = "ثبت دستی",
                notes = notes
            )
            repository.insertLead(entity)
        }
    }

    fun updateLeadStatus(id: Long, newStatus: LeadStatus) {
        viewModelScope.launch {
            val current = _rawDbLeads.value.firstOrNull { it.id == id } ?: return@launch
            repository.updateLead(current.copy(status = newStatus, lastContactedAt = System.currentTimeMillis()))
        }
    }

    fun deleteLead(lead: LeadEntity) {
        viewModelScope.launch {
            repository.deleteLead(lead)
        }
    }

    fun markLeadContacted(id: Long, isSms: Boolean) {
        viewModelScope.launch {
            repository.markContacted(id, isSms)
        }
    }

    // --- Extractor Actions ---
    fun setExtractorText(text: String) {
        _extractorText.value = text
        _extractedContacts.value = PhoneExtractorUtil.extractContacts(text, _extractorCategory.value)
    }

    fun setExtractorCategory(cat: LeadCategory) {
        _extractorCategory.value = cat
        if (_extractorText.value.isNotBlank()) {
            _extractedContacts.value = PhoneExtractorUtil.extractContacts(_extractorText.value, cat)
        }
    }

    fun setExtractorLocation(province: String, city: String, district: String) {
        _extractorProvince.value = province
        _extractorCity.value = city
        _extractorDistrict.value = district
    }

    fun clearExtractor() {
        _extractorText.value = ""
        _extractedContacts.value = emptyList()
        _importedMessage.value = null
    }

    fun insertAllExtractedContacts() {
        val contacts = _extractedContacts.value
        if (contacts.isEmpty()) return

        viewModelScope.launch {
            val entities = contacts.map { contact ->
                LeadEntity(
                    fullName = contact.detectedName,
                    phoneNumber = contact.canonicalPhone,
                    category = contact.suggestedCategory,
                    province = _extractorProvince.value,
                    city = _extractorCity.value,
                    district = _extractorDistrict.value,
                    propertyDetails = contact.contextSnippet.ifBlank { "استخراج خودکار از متن" },
                    status = LeadStatus.NEW,
                    source = "استخراج متن",
                    notes = "متن مبدأ: ${contact.rawNumber}"
                )
            }
            repository.insertLeads(entities)
            _importedMessage.value = "${entities.size} مخاطب با موفقیت به بانک اطلاعاتی افزوده شد!"
            _extractorText.value = ""
            _extractedContacts.value = emptyList()
            delay(3000)
            _importedMessage.value = null
        }
    }

    // --- Campaign Actions ---
    fun selectTemplate(template: CampaignTemplate) {
        _selectedTemplate.value = template
        _campaignCustomText.value = template.messageText
        _campaignCategory.value = template.category
    }

    fun setCampaignCategory(cat: LeadCategory?) {
        _campaignCategory.value = cat
        val matchingTemplate = TemplateRepository.defaultTemplates.firstOrNull { it.category == cat }
        if (matchingTemplate != null) {
            _selectedTemplate.value = matchingTemplate
            _campaignCustomText.value = matchingTemplate.messageText
        }
    }

    fun setCampaignCustomText(text: String) {
        _campaignCustomText.value = text
    }

    fun getTargetAudienceForCampaign(): List<LeadEntity> {
        val all = _rawDbLeads.value
        val cat = _campaignCategory.value
        return if (cat != null) {
            all.filter { it.category == cat }
        } else {
            all
        }
    }
}
