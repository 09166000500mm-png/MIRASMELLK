package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.model.LeadCategory
import com.example.util.PhoneExtractorUtil
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("املاک مارکتینگ", appName)
  }

  @Test
  fun `test phone extractor with Persian and English numbers`() {
    val sample = "مهندس رستمی سازنده: ۰۹۱۲۳۴۵۶۷۸۹ و خریدار: +989351234567"
    val extracted = PhoneExtractorUtil.extractContacts(sample, LeadCategory.BUILDER)
    assertEquals(2, extracted.size)
    assertEquals("09123456789", extracted[0].canonicalPhone)
    assertEquals("09351234567", extracted[1].canonicalPhone)
  }
}
